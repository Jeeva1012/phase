package com.example.mentor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@CrossOrigin(value="http://localhost:4200")
@Controller
@RequestMapping(value= {"/mentor"}) 
public class Mentorcontroller {

	@Autowired 
	private Mentorprofilerepository mentor;
	
	@Autowired 
	private Trainingrepository tr;
	
	@Autowired 
	private Skillsrepository sr;
	
	
//	@RequestMapping(value= {"/"}) 
//public @ResponseBody String mentordefault () {
//		
//		List<Training> l1 = new ArrayList<>();
//		Training t1 = new Training(1,"JAVA",80,50,50,false);
//		l1.add(t1);
//		List<Skills> l2 = new ArrayList<>();
//		Skills s1 = new Skills(1,"JAVA");
//		l2.add(s1);
//		tr.save(t1);
//		sr.save(s1);
//		mentor.save(new Mentorprofile("JUSTIN",l1,l2));
//		
//		return "Default Mentor's Saved";
//	}
	
	@GetMapping(value= {"/profile"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Mentorprofile> profile () {
		return mentor.findAll();
	}
	
	@GetMapping(value= {"/id"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Optional<Mentorprofile> profileid (@RequestBody Integer ids) {
		return mentor.findById(ids);
	}
	
	/*************************************************************************************/
	
//	@Autowired 
//	private Skillsrep skill;
//	
//	@PostMapping(value= {"/addskills"},produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody String addskill (@Valid @RequestBody Skills profile) {
//		
//		skill.save(profile);
//		return "Mentor Saved";
//	}
//	
//	@GetMapping(value= {"/skill"},produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody Iterable<Skills> display () {
//		return skill.findAll();
//	}

}
