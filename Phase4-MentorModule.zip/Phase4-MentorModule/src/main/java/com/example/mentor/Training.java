package com.example.mentor;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Training {
	@Id
	private Integer courseid;
	
	private String coursename;
	
	private Integer percentage;
	
	private Integer amountpaid;
	
	private Integer amountremaining;
	
	private Boolean status;

	public Training() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Training(int i, String string, int j, int k, int l, boolean b) {
		super();
		// TODO Auto-generated constructor stub
	}

	public Training(String coursename, Integer percentage, Integer amountpaid, Integer amountremaining,
			Boolean status) {
		super();
		this.coursename = coursename;
		this.percentage = percentage;
		this.amountpaid = amountpaid;
		this.amountremaining = amountremaining;
		this.status = status;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public Integer getPercentage() {
		return percentage;
	}

	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}

	public Integer getAmountpaid() {
		return amountpaid;
	}

	public void setAmountpaid(Integer amountpaid) {
		this.amountpaid = amountpaid;
	}

	public Integer getAmountremaining() {
		return amountremaining;
	}

	public void setAmountremaining(Integer amountremaining) {
		this.amountremaining = amountremaining;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	

}
