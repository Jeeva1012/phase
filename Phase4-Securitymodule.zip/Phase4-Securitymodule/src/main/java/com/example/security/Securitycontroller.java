package com.example.security;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@CrossOrigin(value="http://localhost:4200")
@Controller    
@RequestMapping(value= {"/main"}) // This means URL's start with /demo (after Application path)
public class Securitycontroller {
	
	
	@Autowired 
	private Authorizationrepository Arep;
	
	@Autowired 
	private Rolerepository Rrep;
	
	@PostMapping(value= {"/addentry"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addNew (@Valid @RequestBody Authorization authority) {
		
		Arep.save(authority);
		return "Added";
	}
	@GetMapping(value= {"/all"})
	public @ResponseBody Iterable<Authorization> getAllUsers() {
		return Arep.findAll();
	}
//	@GetMapping(value= {"/delete/{id}"},produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody String del (@Valid @PathVariable int id) {
//		
//		Arep.deleteById(id);
//		return "Deleted";
//	}
//	@RequestMapping(value= {"/"}) 
//	public @ResponseBody String addNewUser () {
////		Map<Integer,String> person = new HashMap<Integer,String>();
////		Arep.save(new Authorization("Admin","Admin",1,false)); 
//		
//		
//		Rrep.save(new Role(1,"Admin"));
//		Rrep.save(new Role(2,"Mentor"));
//		Rrep.save(new Role(3,"User"));
//
//		return "Saved";
//	}
	
//	@GetMapping(value= {"/all"})
//	public @ResponseBody Iterable<Authorization> getAllUsers() {
//		return Arep.findAll();
//	}
}
