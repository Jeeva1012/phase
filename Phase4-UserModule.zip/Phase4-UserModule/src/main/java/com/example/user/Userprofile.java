package com.example.user;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Userprofile {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer myuserid;
    
    private String username;
    
    private String password;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="role")
    private Role role;

	public Integer getMyuserid() {
		return myuserid;
	}

	public void setMyuserid(Integer myuserid) {
		this.myuserid = myuserid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Userprofile(Integer myuserid, String username, String password, com.example.user.Role role) {
		super();
		this.myuserid = myuserid;
		this.username = username;
		this.password = password;
		this.role = role;
	}

	

}
