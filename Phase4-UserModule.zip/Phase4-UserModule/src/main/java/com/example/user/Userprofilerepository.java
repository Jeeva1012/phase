package com.example.user;

import org.springframework.data.repository.CrudRepository;



public interface Userprofilerepository extends CrudRepository<Userprofile, Integer> {

}
